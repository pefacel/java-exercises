package Automotora;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // File archivo = new File("Automotora/Ficheros/texto.txt");

        String path = "Automotora/Ficheros";
        String nombreArchivo = "texto1.txt";

        String nombreClient = scanner.next();

        System.out.println(nombreClient);

        // crearArchivo(path, nombreArchivo);
    }

    public static void existeDirectorio(String path) {
        File directorio = new File(path);
        if (!directorio.exists()) {
            throw new Error("El directorio no existe.");
        }
    }

    public static void existeArchivo(String path, String nombreArchivo) {
        File directorio = new File(path + "/" + nombreArchivo);
        if (directorio.exists()) {
            throw new Error("El archivo ya existe.");
        }
    }

    public static void crearArchivo(String path, String nombreArchivo) {

        existeDirectorio(path);
        existeArchivo(path, nombreArchivo);

        try {
            File directorio = new File(path + "/" + nombreArchivo);
            directorio.createNewFile();
            FileWriter fileW = new FileWriter(path + "/" + nombreArchivo);
            BufferedWriter bufferedWriter = new BufferedWriter(fileW);
            bufferedWriter.write("texto 1sadasd");
            bufferedWriter.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}